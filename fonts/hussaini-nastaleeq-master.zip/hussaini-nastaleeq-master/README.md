This is a fork of [Nafees Nastaleeq][1] font, adding missing Arabic characters
to make it usable for Arabic users and other general fixes.

It is named after Syed Nafees Al-Hussaini, whose calligraphy style is followed
by Nafees Nastaleeq.

![نظر الله لي فأرشد أبنائي فشدوا إلي العلا أي شد][2]

 [1]: http://www.crulp.org/software/localization/Fonts/nafeesNastaleeq.html "Nafees Nastaleeq web page"
 [2]: https://github.com/khaledhosny/hussaini-nastaleeq/raw/master/sample.png "Font sample"
